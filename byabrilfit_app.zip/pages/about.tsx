import Layout from '../components/Layout';
import Image from 'next/image';
import Link from 'next/link';

export default function About() {
  return (
    <Layout>
      <section
        style={{
          padding: '6rem 2rem 2rem',
          maxWidth: '1000px',
          margin: '0 auto',
        }}
      >
        <h1
          style={{
            fontSize: 'clamp(2rem, 6vw, 4rem)',
            color: 'var(--color-primary)',
            marginBottom: '1rem',
          }}
        >
          Sobre mí
        </h1>
        <p style={{ fontSize: '1.1rem', lineHeight: 1.6, marginBottom: '2rem' }}>
          Soy Abril, entrenadora personal y apasionada del fitness. Mi historia comenzó entrenando en
          un parque con poco equipamiento y muchas ganas. Gracias a la constancia, logré transformar
          mi vida y ahora quiero ayudarte a lograr lo mismo. En esta comunidad encontrarás apoyo,
          motivación y planes de entrenamiento que se adaptan a tus necesidades.
        </p>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '2rem',
            alignItems: 'center',
          }}
        >
          <Image
            src="https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=600&q=80"
            alt="Perfil"
            width={500}
            height={400}
            style={{ borderRadius: '12px' }}
          />
          <div>
            <h3 style={{ color: 'var(--color-primary)', marginBottom: '1rem' }}>Mi comunidad</h3>
            <ul style={{ color: 'var(--color-muted)', fontSize: '1.1rem', lineHeight: 1.5 }}>
              <li>+100k seguidores en Instagram</li>
              <li>+20k suscriptores en YouTube</li>
              <li>+500 alumnos activos</li>
            </ul>
            <div style={{ marginTop: '1rem', display: 'flex', gap: '1rem' }}>
              <Link href="https://instagram.com" passHref>
                <a target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                  <Image
                    src="https://img.icons8.com/ios-glyphs/30/ffffff/instagram-new.png"
                    alt="Instagram"
                    width={30}
                    height={30}
                  />
                </a>
              </Link>
              <Link href="https://youtube.com" passHref>
                <a target="_blank" rel="noopener noreferrer" aria-label="YouTube">
                  <Image
                    src="https://img.icons8.com/ios-glyphs/30/ffffff/youtube-play.png"
                    alt="YouTube"
                    width={30}
                    height={30}
                  />
                </a>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}