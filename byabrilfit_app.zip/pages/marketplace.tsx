import Layout from '../components/Layout';
import Image from 'next/image';
import Link from 'next/link';

const products = [
  {
    slug: 'modo-oso-20',
    title: 'Modo Oso 2.0',
    description: 'Programa de ganancia de masa y fuerza.',
    price: '$19.99',
    img: 'https://images.unsplash.com/photo-1526403420519-f85f8db420f4?auto=format&fit=crop&w=600&q=80',
  },
  {
    slug: 'anabolico',
    title: 'Recetario Anabólico',
    description: 'Recetas sabrosas para crecer.',
    price: '$14.99',
    img: 'https://images.unsplash.com/photo-1514519106315-38eaa042cfd9?auto=format&fit=crop&w=600&q=80',
  },
  {
    slug: 'powerbuilding',
    title: 'Powerbuilding',
    description: 'Combina fuerza y estética.',
    price: '$24.99',
    img: 'https://images.unsplash.com/photo-1519866841-0e3d0390b1ee?auto=format&fit=crop&w=600&q=80',
  },
];

export default function Marketplace() {
  return (
    <Layout>
      <section style={{ padding: '6rem 2rem', maxWidth: '1200px', margin: '0 auto' }}>
        <h1 style={{ color: 'var(--color-primary)', textAlign: 'center', marginBottom: '2rem' }}>
          Tienda
        </h1>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '2rem',
          }}
        >
          {products.map((product) => (
            <div
              key={product.slug}
              style={{
                background: 'var(--color-card)',
                borderRadius: '12px',
                overflow: 'hidden',
                boxShadow: '0 8px 16px rgba(0,0,0,0.3)',
                transition: 'transform 0.3s ease, box-shadow 0.3s ease',
              }}
            >
              <Link href={`/info/${product.slug}`}>
                <a style={{ display: 'block', height: '100%' }}>
                  <div style={{ position: 'relative', height: '200px' }}>
                    <Image src={product.img} alt={product.title} layout="fill" objectFit="cover" />
                    <span
                      style={{
                        position: 'absolute',
                        top: '8px',
                        right: '8px',
                        background: 'rgba(0,0,0,0.6)',
                        color: '#fff',
                        borderRadius: '50%',
                        width: '32px',
                        height: '32px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '1.2rem',
                      }}
                    >
                      i
                    </span>
                  </div>
                  <div style={{ padding: '1rem' }}>
                    <h3 style={{ color: 'var(--color-primary)', margin: '0 0 0.5rem 0' }}>{product.title}</h3>
                    <p style={{ color: 'var(--color-muted)', margin: '0 0 0.5rem 0' }}>{product.description}</p>
                    <p style={{ color: 'var(--color-primary)', fontWeight: 600 }}>{product.price}</p>
                  </div>
                </a>
              </Link>
            </div>
          ))}
        </div>
      </section>
    </Layout>
  );
}