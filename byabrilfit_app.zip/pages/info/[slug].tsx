import { useRouter } from 'next/router';
import Layout from '../../components/Layout';
import Image from 'next/image';

const products = {
  'modo-oso-20': {
    title: 'Modo Oso 2.0',
    description:
      'Un programa enfocado en ganar masa y fuerza, con entrenamientos progresivos y nutrición controlada.',
    img: 'https://images.unsplash.com/photo-1526403420519-f85f8db420f4?auto=format&fit=crop&w=1200&q=80',
    includes: ['Entrenamientos personalizados', 'Plan de alimentación', 'Sesiones en vivo'],
    benefits: ['Aumento de masa muscular', 'Mejora de fuerza', 'Cambios visibles en 8 semanas'],
  },
  anabolico: {
    title: 'Recetario Anabólico',
    description:
      'Recetas deliciosas altas en proteína para apoyar tu crecimiento muscular sin sacrificar sabor.',
    img: 'https://images.unsplash.com/photo-1514519106315-38eaa042cfd9?auto=format&fit=crop&w=1200&q=80',
    includes: ['Más de 50 recetas', 'Plan de comidas semanal', 'Lista de compras'],
    benefits: ['Facilita la nutrición', 'Variedad de platos', 'Ahorro de tiempo'],
  },
  powerbuilding: {
    title: 'Powerbuilding',
    description:
      'Combina lo mejor del powerlifting y bodybuilding para fuerza y estética en un solo programa.',
    img: 'https://images.unsplash.com/photo-1519866841-0e3d0390b1ee?auto=format&fit=crop&w=1200&q=80',
    includes: ['Rutinas mixtas', 'Planificación semanal', 'Guías de técnica'],
    benefits: ['Fuerza máxima', 'Fisico equilibrado', 'Variedad de ejercicios'],
  },
};

export default function InfoPage() {
  const router = useRouter();
  const { slug } = router.query as { slug: keyof typeof products };
  const product = products[slug];
  if (!product) {
    return <Layout>Producto no encontrado.</Layout>;
  }
  return (
    <Layout>
      <section style={{ position: 'relative', height: '60vh', overflow: 'hidden' }}>
        <Image src={product.img} alt={product.title} layout="fill" objectFit="cover" />
        <div
          style={{
            position: 'absolute',
            bottom: '20%',
            left: '5%',
            color: '#fff',
            maxWidth: '60%',
          }}
        >
          <h1
            style={{ fontSize: 'clamp(2rem, 6vw, 4rem)', color: 'var(--color-primary)', marginBottom: '0.5rem' }}
          >
            {product.title}
          </h1>
          <p style={{ fontSize: '1.1rem', lineHeight: 1.5 }}>{product.description}</p>
        </div>
      </section>
      <section style={{ padding: '4rem 2rem', maxWidth: '1000px', margin: '0 auto' }}>
        <h2 style={{ color: 'var(--color-primary)', marginBottom: '1rem' }}>¿Qué incluye?</h2>
        <ul style={{ color: 'var(--color-muted)', lineHeight: 1.6, marginBottom: '2rem' }}>
          {product.includes.map((item, i) => (
            <li key={i}>• {item}</li>
          ))}
        </ul>
        <h2 style={{ color: 'var(--color-primary)', marginBottom: '1rem' }}>Beneficios</h2>
        <ul style={{ color: 'var(--color-muted)', lineHeight: 1.6, marginBottom: '2rem' }}>
          {product.benefits.map((item, i) => (
            <li key={i}>• {item}</li>
          ))}
        </ul>
        <h2 style={{ color: 'var(--color-primary)', marginBottom: '1rem' }}>Preguntas frecuentes</h2>
        <details style={{ marginBottom: '1rem' }}>
          <summary style={{ cursor: 'pointer', fontWeight: 600 }}>¿Cuánto dura el programa?</summary>
          <p style={{ color: 'var(--color-muted)', paddingLeft: '1rem' }}>Entre 8 y 12 semanas.</p>
        </details>
        <details style={{ marginBottom: '1rem' }}>
          <summary style={{ cursor: 'pointer', fontWeight: 600 }}>¿Necesito equipo?</summary>
          <p style={{ color: 'var(--color-muted)', paddingLeft: '1rem' }}>Se recomienda pero no es obligatorio.</p>
        </details>
        <button
          style={{
            background: 'var(--color-primary)',
            color: '#0b0b0b',
            padding: '0.75rem 2rem',
            borderRadius: '8px',
            fontWeight: 600,
            marginTop: '2rem',
            display: 'block',
            width: 'fit-content',
          }}
          onClick={() => alert('Redireccionando a pago...')}
        >
          Empezá hoy
        </button>
      </section>
    </Layout>
  );
}