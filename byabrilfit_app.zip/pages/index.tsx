import { useEffect, useRef } from 'react';
import Layout from '../components/Layout';
import Image from 'next/image';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';

gsap.registerPlugin(ScrollTrigger);

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const heroTitleRef = useRef<HTMLHeadingElement>(null);
  const pinnedRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!heroRef.current || !heroTitleRef.current) return;
    const ctx = gsap.context(() => {
      // scale down hero image and title on scroll
      gsap.to(heroTitleRef.current, {
        scale: 0.6,
        y: -150,
        scrollTrigger: {
          trigger: heroRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        },
      });
    }, heroRef);

    return () => ctx.revert();
  }, []);

  useEffect(() => {
    if (!pinnedRef.current) return;
    const ctx = gsap.context(() => {
      const paragraphs = pinnedRef.current?.querySelectorAll('.pinned-text');
      paragraphs?.forEach((el, i) => {
        gsap.fromTo(
          el,
          { opacity: 0, y: 50 },
          {
            opacity: 1,
            y: 0,
            scrollTrigger: {
              trigger: pinnedRef.current,
              start: 'top center+=' + i * 100,
              end: '+=150',
              scrub: true,
            },
          }
        );
      });
    }, pinnedRef);
    return () => ctx.revert();
  }, []);

  return (
    <Layout>
      {/* Hero Section */}
      <section
        ref={heroRef}
        style={{
          position: 'relative',
          height: '100vh',
          overflow: 'hidden',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
        }}
      >
        <Image
          src="https://images.unsplash.com/photo-1526406915893-7bcd65f60845?auto=format&fit=crop&w=2100&q=80"
          alt="Hero"
          layout="fill"
          objectFit="cover"
          style={{ filter: 'brightness(0.4)' }}
        />
        <h1
          ref={heroTitleRef}
          style={{
            color: 'var(--color-primary)',
            fontSize: 'clamp(2.5rem, 10vw, 8rem)',
            fontFamily: 'Playfair Display, serif',
            letterSpacing: '4px',
            margin: 0,
            zIndex: 2,
          }}
        >
          AESTHETIC
        </h1>
      </section>

      {/* Pinned Text Section */}
      <section
        ref={pinnedRef}
        style={{ padding: '10rem 2rem', maxWidth: '1200px', margin: '0 auto' }}
      >
        <div className="pinned-text" style={{ marginBottom: '6rem' }}>
          <h2 style={{ color: 'var(--color-primary)', fontSize: '2rem', marginBottom: '1rem' }}>
            Conóceme
          </h2>
          <p style={{ fontSize: '1.1rem', lineHeight: 1.6 }}>
            Descubre mi viaje de transformación y cómo puedo ayudarte a alcanzar tu mejor versión.
          </p>
        </div>
        <div className="pinned-text" style={{ marginBottom: '6rem' }}>
          <h2 style={{ color: 'var(--color-primary)', fontSize: '2rem', marginBottom: '1rem' }}>
            Planes Personalizados
          </h2>
          <p style={{ fontSize: '1.1rem', lineHeight: 1.6 }}>
            Ofrecemos programas de entrenamiento adaptados a tus objetivos y estilo de vida para resultados sostenibles.
          </p>
        </div>
        <div className="pinned-text" style={{ marginBottom: '6rem' }}>
          <h2 style={{ color: 'var(--color-primary)', fontSize: '2rem', marginBottom: '1rem' }}>
            Comunidad
          </h2>
          <p style={{ fontSize: '1.1rem', lineHeight: 1.6 }}>
            Únete a una comunidad global comprometida con la salud y el bienestar, donde el apoyo mutuo es clave.
          </p>
        </div>
      </section>

      {/* Marketplace Section */}
      <section style={{ padding: '6rem 2rem', background: 'var(--color-card)' }}>
        <h2 style={{ textAlign: 'center', color: 'var(--color-primary)', marginBottom: '3rem' }}>
          Tienda
        </h2>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '2rem',
            maxWidth: '1200px',
            margin: '0 auto',
          }}
        >
          {[
            {
              slug: 'modo-oso-20',
              title: 'Modo Oso 2.0',
              img: 'https://images.unsplash.com/photo-1526403420519-f85f8db420f4?auto=format&fit=crop&w=600&q=80',
              price: '$19.99',
            },
            {
              slug: 'anabolico',
              title: 'Recetario Anabólico',
              img: 'https://images.unsplash.com/photo-1514519106315-38eaa042cfd9?auto=format&fit=crop&w=600&q=80',
              price: '$14.99',
            },
            {
              slug: 'powerbuilding',
              title: 'Powerbuilding',
              img: 'https://images.unsplash.com/photo-1519866841-0e3d0390b1ee?auto=format&fit=crop&w=600&q=80',
              price: '$24.99',
            },
          ].map((product) => (
            <div
              key={product.slug}
              style={{
                position: 'relative',
                background: 'var(--color-background)',
                borderRadius: '12px',
                overflow: 'hidden',
                boxShadow: '0 8px 16px rgba(0,0,0,0.4)',
                transition: 'transform 0.3s ease, box-shadow 0.3s ease',
              }}
            >
              <Link href={`/info/${product.slug}`}>
                <a style={{ display: 'block', height: '100%' }}>
                  <div style={{ position: 'relative', width: '100%', height: '200px' }}>
                    <Image src={product.img} alt={product.title} layout="fill" objectFit="cover" />
                    <span
                      style={{
                        position: 'absolute',
                        top: '8px',
                        right: '8px',
                        background: 'rgba(0,0,0,0.6)',
                        color: '#fff',
                        borderRadius: '50%',
                        width: '32px',
                        height: '32px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '1.2rem',
                      }}
                    >
                      i
                    </span>
                  </div>
                  <div style={{ padding: '1rem' }}>
                    <h3 style={{ margin: '0 0 0.5rem 0', fontSize: '1.3rem', color: 'var(--color-primary)' }}>
                      {product.title}
                    </h3>
                    <p style={{ margin: 0, color: 'var(--color-muted)' }}>{product.price}</p>
                  </div>
                </a>
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Quiz Section */}
      <section style={{ padding: '6rem 2rem', maxWidth: '800px', margin: '0 auto' }}>
        <h2 style={{ textAlign: 'center', color: 'var(--color-primary)', marginBottom: '2rem' }}>
          Encuentra tu plan ideal
        </h2>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            alert('Gracias por responder. Te contactaremos con el mejor plan.');
          }}
          style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}
        >
          <label>
            ¿Cuál es tu objetivo principal?
            <select required style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }}>
              <option value="masa">Ganar masa muscular</option>
              <option value="definicion">Definición</option>
              <option value="fuerza">Mejorar fuerza</option>
              <option value="salud">Salud general</option>
            </select>
          </label>
          <label>
            ¿Cuántos días a la semana entrenas?
            <input type="number" min={1} max={7} required style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }} />
          </label>
          <button
            type="submit"
            style={{
              marginTop: '1rem',
              background: 'var(--color-primary)',
              color: '#0b0b0b',
              padding: '0.75rem',
              borderRadius: '8px',
              fontWeight: 600,
            }}
          >
            Enviar
          </button>
        </form>
      </section>

      {/* FAQ Section */}
      <section style={{ padding: '6rem 2rem', background: 'var(--color-card)' }}>
        <h2 style={{ textAlign: 'center', color: 'var(--color-primary)', marginBottom: '2rem' }}>
          Preguntas Frecuentes
        </h2>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          {[
            {
              q: '¿Necesito equipo para entrenar?',
              a: 'Puedes entrenar con o sin equipo. Ofrecemos opciones de entrenamiento en casa y en gimnasio.',
            },
            {
              q: '¿Cuál es la duración de los planes?',
              a: 'Los planes duran entre 8 y 12 semanas dependiendo de tu objetivo y nivel.',
            },
            {
              q: '¿Ofrecen asesoramiento personalizado?',
              a: 'Sí, contamos con servicios uno a uno para acompañarte en cada paso de tu transformación.',
            },
          ].map((item, i) => (
            <details key={i} style={{ marginBottom: '1rem' }}>
              <summary style={{ cursor: 'pointer', fontSize: '1.1rem', fontWeight: 600 }}>
                {item.q}
              </summary>
              <p style={{ padding: '0.5rem 0 0.5rem 1rem', color: 'var(--color-muted)', lineHeight: 1.5 }}>
                {item.a}
              </p>
            </details>
          ))}
        </div>
      </section>
    </Layout>
  );
}