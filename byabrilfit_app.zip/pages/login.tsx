import Layout from '../components/Layout';

export default function Login() {
  return (
    <Layout>
      <section style={{ padding: '6rem 2rem', maxWidth: '600px', margin: '0 auto' }}>
        <h1 style={{ color: 'var(--color-primary)', textAlign: 'center', marginBottom: '2rem' }}>Login</h1>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            alert('Funcionalidad de inicio de sesión próximamente.');
          }}
          style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}
        >
          <label>
            Correo electrónico
            <input type="email" required style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }} />
          </label>
          <label>
            Contraseña
            <input type="password" required style={{ width: '100%', padding: '0.5rem', marginTop: '0.5rem' }} />
          </label>
          <button
            type="submit"
            style={{
              marginTop: '1rem',
              background: 'var(--color-primary)',
              color: '#0b0b0b',
              padding: '0.75rem',
              borderRadius: '8px',
              fontWeight: 600,
            }}
          >
            Iniciar sesión
          </button>
        </form>
      </section>
    </Layout>
  );
}